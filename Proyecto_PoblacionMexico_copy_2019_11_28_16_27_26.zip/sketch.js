var stats;
var num = 1990
var mus;
var women = [];
var men = [];
var anio = [];
var all = [];
var x = 0;

function preload() {
  stats = loadTable("PoblacionEstadodeMexico.csv");
  mus = loadSound("sf.mp3");
}

function setup() {
  createCanvas(700, 600);
   mus.play();
   mus.loop();
}

function draw() {
  strokeWeight(1);
  stroke(10);
  background(255, 255, 255);
  
  //Recuperar los datos
  for (var i = 0; i < stats.getRowCount(); i++) {
    //Recupera el valor de la fila i, columna 0 del archivo
    anio[i] = stats.get(i, 0);
    // Recupera el valor de la fila i, columna 1 del archivo
    all[i] = stats.get(i, 1);
    women[i] = stats.get(i, 2);
    men[i] = stats.get(i, 3);

  }

  mus.setVolume(0.4);
  fill(75, 140, 206);

  textSize(27);
  text('Estado de México: Población 1990-2010', 105, 55);
  textSize(12);
  
  text(women[0], 100, 540);
  text(women[1], 200, 540);
  text(women[2], 300, 540);
  text(women[3], 400, 540);
  text(women[4], 500, 540);
  text(women[5], 600, 540);
  
  
  text(men[0], 100, 560);
  text(men[1], 200, 560);
  text(men[2], 300, 560);
  text(men[3], 400, 560);
  text(men[4], 500, 560);
  text(men[5], 600, 560);

  text(all[0], 100, 580);
  text(all[1], 200, 580);
  text(all[2], 300, 580);
  text(all[3], 400, 580);
  text(all[4], 500, 580);
  text(all[5], 600, 580);
  
  
  noFill();

  rect(100, 25, 500, 45);
  rect(0, 0, 700, 600);
  textSize(20);
  fill(66, 65, 67);

  // Barra de persona 
  frameRate(10);

  fill("pink");
  rect(125, 450, 25, -220);

  fill("aqua");
  rect(150, 450, 25, -230);

  fill("pink");
  rect(225, 450, 25, -215);

  fill("aqua");
  rect(250, 450, 25, -225);

  fill("pink");
  rect(325, 450, 25, -290);
  fill("aqua");
  rect(350, 450, 25, -300);

  fill("pink");
  rect(425, 450, 25, -265);
  fill("aqua");
  rect(450, 450, 25, -320);

  fill("pink");
  rect(525, 450, 25, -330);
  fill("aqua");
  rect(550, 450, 25, -340);

  line(100, 450, 600, 450);
  line(100, 80, 100, 450);

  textSize(12);
  fill(66, 65, 67);
  noStroke();
  text(num, 140, 470);
  text(num + 5, 240, 470);
  text(num + 10, 340, 470);
  text(num + 15, 440, 470);
  text(num + 20, 540, 470);

  strokeWeight(10);
  stroke(2);
  point(100, 362);
  point(100, 275);
  point(100, 187);
  point(100, 100);

  stroke("red");
  point(137.5, 230);
  point(237.5, 235);
  point(337.5, 160);
  point(437.5, 185);
  point(537.5, 120);

  stroke("green");
  point(162.5, 220);
  point(262.5, 225);
  point(362.5, 150);
  point(462.5, 130);
  point(562.5, 110);

  noStroke();

  //Señala el color de las barras
  fill("pink");
  rect(200, 500, 20, 20);
  fill("aqua");
  rect(400, 500, 20, 20);

  textSize(18);
  fill(66, 65, 67);

  text("Mujeres", 225, 517);
  text("Hombres", 425, 517);
  
  textSize(10);
  text("Acerca tu mouse a cualquier punto rojo o verde",200,15);
  text("Año", 610, 450);
  text("Millones de personas", 3, 75)
  
  text("2M", 70, 362);
  text("4M", 70, 275);
  text("6M", 70, 186);
  text("8M", 70, 100);
  
  let d = dist(mouseX, mouseY, 137.5, 230);
  let d2 = dist(mouseX, mouseY, 237.5, 235);
  let d3 = dist(mouseX, mouseY, 337.5, 160);
  let d4 = dist(mouseX, mouseY, 437.5, 185);
  let d5 = dist(mouseX, mouseY, 537.5, 120);
  
  if (d < 10 || d2 < 10 || d3 < 10 || d4 < 10 || d5 < 10) {
    // escoger nuevos colores aleatorios
   
    fill("pink");
    textSize(15);
    text(women[1], 100, 190);
    text(women[2], 200, 190);
    text(women[3], 300, 125);
    text(women[4], 400, 100);
    text(women[5], 500, 90);

  }

  let d6 = dist(mouseX, mouseY, 162.5, 220);
  let d7 = dist(mouseX, mouseY, 262.5, 225);
  let d8 = dist(mouseX, mouseY, 362.5, 150);
  let d9 = dist(mouseX, mouseY, 462.5, 130);
  let d10 = dist(mouseX, mouseY, 562.5, 110);

  if (d6 < 10 || d7 < 10 || d8 < 10 || d9 < 10 || d10 < 10) {
    // escoger nuevos colores aleatorios

    fill("aqua");
    textSize(15);
    text(men[1], 100, 190);
    text(men[2], 200, 190);
    text(men[3], 300, 125);
    text(men[4], 400, 100);
    text(men[5], 500, 90);
  }

}